// ears
// ear_cap
// horn
// root
// join11	-> root
// joint12	-> join11
// joint13	-> joint12
// joint2	-> root
// joint21	-> joint2
// joint22	-> joint21
// joint31	-> joint2
// joint32	-> joint31
// joint33	-> joint32
// joint41	-> root
// joint42	-> joint41
// joint43	-> joint42
// joint44	-> joint43
// joint51	-> root
// joint52	-> joint51
// joint53	-> joint52
// joint54	-> joint53
// joint55	-> joint54
// joint61	-> root
// joint62	-> joint61
// joint63	-> joint62
// joint71	-> root
// joint72	-> joint71
// joint73	-> joint72
// face_collider
// joint13_	-> joint13
// joint23	-> joint22
// joint34	-> joint33
// joint45	-> joint44
// joint56	-> joint55
// joint64	-> joint63
// joint74	-> joint73

function Effect() {
	var self = this;
	var Timer;
	var Delay = 3900;
	var setted = true;

	this.play = function () {
		var now = (new Date()).getTime();
		if (Api.getPlatform() == "ios") {
			if (now > Timer && !setted) {
				Api.playVideoRange("frx", 0, 0.001, false, 1);
				setted = true;
			}

			if (now > Timer && isSmile(world.landmarks, world.latents)) {
				Api.hideHint();
				Api.playVideoRange("frx", 0, 3.9, false, 1);
				Timer = now + Delay;
				setted = false;
			}
		} else {
			if (now > Timer && isSmile(world.landmarks, world.latents)) {
				Api.hideHint();
				Api.playVideo("frx", false, 1);
				Timer = now + Delay;
			}
		}
	};

	this.init = function () {
		Timer = 0;
		Api.meshfxMsg("spawn", 1, 0, "!glfx_FACE");
		Api.meshfxMsg("spawn", 0, 0, "Unicorn_13.bsm2");
		// Api.meshfxMsg("animOnce", 0, 0, "static");

		Api.meshfxMsg("dynImass", 0, 0, "ears");
		Api.meshfxMsg("dynImass", 0, 0, "ear_cap");
		Api.meshfxMsg("dynImass", 0, 0, "horn");
		Api.meshfxMsg("dynImass", 0, 0, "root");
		Api.meshfxMsg("dynImass", 0, 0, "cut");
		Api.meshfxMsg("dynImass", 0, 0, "ears1");

		Api.meshfxMsg("dynImass", 0, 0, "join11");
		Api.meshfxMsg("dynImass", 0, 0, "joint12");
		Api.meshfxMsg("dynImass", 0, 3, "joint13");
		Api.meshfxMsg("dynImass", 0, 0, "joint13_");

		Api.meshfxMsg("dynImass", 0, 0, "joint2");
		Api.meshfxMsg("dynImass", 0, 0, "joint21");
		Api.meshfxMsg("dynImass", 0, 3, "joint22");
		Api.meshfxMsg("dynImass", 0, 0, "joint23");

		Api.meshfxMsg("dynImass", 0, 0, "joint31");
		Api.meshfxMsg("dynImass", 0, 0, "joint32");
		Api.meshfxMsg("dynImass", 0, 3, "joint33");
		Api.meshfxMsg("dynImass", 0, 0, "joint34");

		Api.meshfxMsg("dynImass", 0, 0, "joint41");
		Api.meshfxMsg("dynImass", 0, 0, "joint42");
		Api.meshfxMsg("dynImass", 0, 0, "joint43");
		Api.meshfxMsg("dynImass", 0, 3, "joint44");
		Api.meshfxMsg("dynImass", 0, 0, "joint45");

		Api.meshfxMsg("dynImass", 0, 0, "joint51");
		Api.meshfxMsg("dynImass", 0, 0, "joint52");
		Api.meshfxMsg("dynImass", 0, 0, "joint53");
		Api.meshfxMsg("dynImass", 0, 0, "joint54");
		Api.meshfxMsg("dynImass", 0, 3, "joint55");
		Api.meshfxMsg("dynImass", 0, 0, "joint56");

		Api.meshfxMsg("dynImass", 0, 0, "joint61");
		Api.meshfxMsg("dynImass", 0, 0, "joint62");
		Api.meshfxMsg("dynImass", 0, 3, "joint63");
		Api.meshfxMsg("dynImass", 0, 0, "joint64");

		Api.meshfxMsg("dynImass", 0, 0, "joint71");
		Api.meshfxMsg("dynImass", 0, 0, "joint72");
		Api.meshfxMsg("dynImass", 0, 3, "joint73");
		Api.meshfxMsg("dynImass", 0, 0, "joint74");

		Api.meshfxMsg("dynImass", 0, 0, "face_collider");

		// Api.meshfxMsg("dynSphere", 0, 0, "-10 14 15 100");
			//	Api.meshfxMsg("dynSphere", 0, 0, "-20 -5 20 70");

		Api.meshfxMsg("dynGravity", 0, 0, "0 -700 0");
		
		Api.playSound("Unicorn_v2_L.ogg",true,1);
		Api.playVideoRange("frx", 0, 0.001, false, 1);
		self.faceActions = [self.play];
		Api.showHint("Smile");
		Api.showRecordButton();
	};

	this.restart = function () {
		Api.meshfxReset();
		// Api.stopVideo("frx");
		// Api.stopSound("sfx.aac");
		self.init();
	};

	this.faceActions = [];
	this.noFaceActions = [];

	this.videoRecordStartActions = [];
	this.videoRecordFinishActions = [];
	this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());